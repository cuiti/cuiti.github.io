java -cp jade.jar:jade-monitor.jar jade.Boot -gui -nomtp manager:agentes.AgenteAdmin pause
